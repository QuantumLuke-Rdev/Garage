import { Component, OnInit, Output } from '@angular/core';
import { Car } from 'src/classes/car';

@Component({
  selector: 'app-garage-displayer',
  templateUrl: './garage-displayer.component.html',
  styleUrls: ['./garage-displayer.component.css']
})
export class GarageDisplayerComponent{

  static garage : Car[] = [];

  getGarage(): Car[] { return GarageDisplayerComponent.garage}

}
