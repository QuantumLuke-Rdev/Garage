import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Car } from 'src/classes/car';
import { GarageDisplayerComponent } from '../garage-displayer/garage-displayer.component';

@Component({
  selector: 'app-create-car-form',
  templateUrl: './create-car-form.component.html',
  styleUrls: ['./create-car-form.component.css']
})
export class CreateCarFormComponent{

  license = new FormControl('');
  model = new FormControl('');
  brand = new FormControl('');

  addCar() : void{
    GarageDisplayerComponent.garage.push(new Car(this.license.value, this.brand.value, this.model.value));
  }

  reset() : void{
    this.license.setValue('');
    this.model.setValue('');
    this.brand.setValue('');
  }
}
